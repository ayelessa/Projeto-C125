package ProjetoHospital;

public class Arquivo {



}
